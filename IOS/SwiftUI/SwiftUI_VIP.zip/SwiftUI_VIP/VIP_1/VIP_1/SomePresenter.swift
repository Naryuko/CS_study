//
//  SomePresenter.swift
//  VIP_1
//
//  Created by Gyuyoung Hur on 2022/03/16.
//

import Foundation

protocol SomePresentLogic {
    func presentDoSomething(response: Something.something.Response)
}

class SomePresenter: SomePresentLogic {
    var view: SomeDisplayLogic?

    func presentDoSomething(response: Something.something.Response) {
        view?.displayDoSomething(viewModel: .init())
    }
}
