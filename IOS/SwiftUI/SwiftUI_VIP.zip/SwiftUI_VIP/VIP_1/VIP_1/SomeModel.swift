//
//  SomeModel.swift
//  VIP_1
//
//  Created by Gyuyoung Hur on 2022/03/16.
//

import Foundation

enum Something {
    enum something {
        struct Request {}
        struct Response {}
        struct ViewModel {}
    }
}
