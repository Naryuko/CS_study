//
//  SomeInteractor.swift
//  VIP_1
//
//  Created by Gyuyoung Hur on 2022/03/16.
//

import Foundation

protocol SomeBusinessLogic {
    func doSomething(request: Something.something.Request)
}

class SomeInteractor: SomeBusinessLogic {
    var presenter: SomePresentLogic?

    func doSomething(request: Something.something.Request) {
        presenter?.presentDoSomething(response: .init())
    }
}
