//
//  VIP_1App.swift
//  VIP_1
//
//  Created by Gyuyoung Hur on 2022/03/16.
//

import SwiftUI

@main
struct VIP_1App: App {
    var body: some Scene {
        WindowGroup {
            SomeView()
                .configureView()
        }
    }
}
