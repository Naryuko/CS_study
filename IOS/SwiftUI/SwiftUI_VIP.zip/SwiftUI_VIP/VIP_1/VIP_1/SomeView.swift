//
//  ContentView.swift
//  VIP_1
//
//  Created by Gyuyoung Hur on 2022/03/16.
//

import SwiftUI

protocol SomeDisplayLogic {
    func displayDoSomething(viewModel: Something.something.ViewModel)
}

struct SomeView: View {
    var interactor: SomeInteractor?
    @ObservedObject var dataStore = SomeDataStore()

    var body: some View {
        VStack {
            Spacer()
            Text("\(dataStore.someInt)").font(.largeTitle)
            Spacer()
            Button("add 1") {
                interactor?.doSomething(request: .init())
            }
            Spacer()
        }
    }
}

extension SomeView: SomeDisplayLogic {
    func displayDoSomething(viewModel: Something.something.ViewModel) {
        dataStore.someInt += 1
    }
}

extension SomeView {
    func configureView() -> some View {
        var view = self
        let interactor = SomeInteractor()
        let presenter = SomePresenter()
        view.interactor = interactor
        interactor.presenter = presenter
        presenter.view = view

        return view
    }
}
