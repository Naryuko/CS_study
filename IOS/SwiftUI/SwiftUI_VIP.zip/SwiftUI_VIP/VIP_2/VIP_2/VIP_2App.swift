//
//  VIP_2App.swift
//  VIP_2
//
//  Created by Gyuyoung Hur on 2022/03/16.
//

import SwiftUI

@main
struct VIP_2App: App {
    var body: some Scene {
        let appState = AppState()

        WindowGroup {
            SomeView()
                .environment(\.interactor, SomeInteractor(appState: appState))
                .environmentObject(appState)
        }
    }
}
