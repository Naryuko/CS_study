//
//  SomeInteractor.swift
//  VIP_2
//
//  Created by Gyuyoung Hur on 2022/03/16.
//

import Foundation
import SwiftUI

struct SomeInteractor: EnvironmentKey {
    var appState: AppState?

    static var defaultValue: SomeInteractor = SomeInteractor()

    func doSomething() {
        appState?.someInt += 1
    }
}

extension EnvironmentValues {
    var interactor: SomeInteractor {
        get {
            self[SomeInteractor.self]
        }

        set {
            self[SomeInteractor.self] = newValue
        }
    }
}
