//
//  ContentView.swift
//  VIP_2
//
//  Created by Gyuyoung Hur on 2022/03/16.
//

import SwiftUI

struct SomeView: View {
    @EnvironmentObject var appState: AppState
    @Environment(\.interactor) var interactor: SomeInteractor

    var body: some View {
        VStack {
            Spacer()
            Text("\(appState.someInt)").font(.largeTitle)
            Spacer()
            Button("add 1") {
                interactor.doSomething()
            }
            Spacer()
        }
    }
}
