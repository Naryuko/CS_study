//
//  AppState.swift
//  VIP_2
//
//  Created by Gyuyoung Hur on 2022/03/16.
//

import Foundation

class AppState: ObservableObject {
    @Published var someInt = 1
}

